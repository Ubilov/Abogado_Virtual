require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const CONTACTOS_PATH = path.join(__dirname, 'contactos.json');

// Ruta para guardar contacto desde formulario
app.post('/guardar-contacto', (req, res) => {
  const { nombre, telefono, email, mensaje } = req.body;

  if (!nombre || !telefono || !email || !mensaje) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }

  const nuevoContacto = {
    nombre,
    telefono,
    email,
    mensaje,
    fecha: new Date().toISOString()
  };

  fs.readFile(CONTACTOS_PATH, 'utf8', (err, data) => {
    let contactos = [];
    if (!err && data) {
      try {
        contactos = JSON.parse(data);
      } catch (e) {
        console.error('Error al parsear contactos.json:', e.message);
      }
    }

    contactos.push(nuevoContacto);

    fs.writeFile(CONTACTOS_PATH, JSON.stringify(contactos, null, 2), (err) => {
      if (err) {
        console.error('Error al guardar contacto:', err.message);
        return res.status(500).json({ error: 'No se pudo guardar el contacto' });
      }
      res.json({ mensaje: '✅ Contacto guardado correctamente' });
    });
  });
});

const PORT = process.env.PORT || 5500;
app.listen(PORT, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
});
